package Sampleworkout;

public class Smarthomeapp {

	 public static void main(String[] args) {

	     Smartdevice device;

	     device = new SmartLight();
	     device.turnOn();
	     device.turnOff();

	     System.out.println();

	     device = new SmartFan();
	     device.turnOn();
	     device.turnOff();
	 }
	}
