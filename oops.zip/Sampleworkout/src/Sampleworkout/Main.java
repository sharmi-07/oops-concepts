package Sampleworkout;

public class Main {

	 public static void main(String[] args) {

	     Student s = new Student();

	   
	     s.name = "sharmi";
	     s.rollNumber = 1322;   
	     s.setMarks(85);       
	     System.out.println("Grade: " + s.getGrade());

	     System.out.println();

	   
	     Teacher t = new Teacher();
	     t.name = "maha";
	     t.rollNumber = 2603;
	     t.setMarks(85);
	     t.showStudentInfo();
	 }
	}

