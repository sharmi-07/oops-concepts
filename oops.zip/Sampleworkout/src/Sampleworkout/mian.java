package Sampleworkout;

public class mian {

    public static void main(String[] args) {

        Employee e1 = new Employee("sharmi");
        Employee e2 = new Employee("Maha");
        Employee e3 = new Employee("Hari");

        e1.displayEmployee();
        System.out.println();

        e2.displayEmployee();
        System.out.println();

        e3.displayEmployee();
        System.out.println();

        // Access static method
        System.out.println("Total Employees: " + Employee.getEmployeeCount());
    }
}
