package Sampleworkout;

public class Bankaccount {
	private int accountnumber;
	private double balance;
	 Bankaccount(int accountNumber, double balance) {
	        this.accountnumber = accountnumber;
	        this.balance = balance;
	    }
	
public void deposit(double amount) {
	 if (amount > 0) {
         balance = balance + amount;
         System.out.println("Amount Deposited: " + amount);
     } else {
         System.out.println("Invalid deposit amount");
     }
}
public void withdraw(double amount) {
	 if (amount > 0 && amount <= balance) {
         balance = balance - amount;
         System.out.println("Amount Withdrawn: " + amount);
     } else {
         System.out.println("Insufficient balance or invalid amount");
     }	
}
public double getbalance() {
	return  balance;
}


	public static void main(String[] args) {
		Bankaccount acc = new Bankaccount(12345, 5000);
        acc.deposit(2000);
        acc.withdraw(1500);
        System.out.println("Current Balance: " + acc.getbalance());

	}

}
