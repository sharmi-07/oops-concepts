package Sampleworkout;

class Employee {

    // Static variables (shared data)
    static String companyName = "Tech Solutions";
    static int employeeCount = 0;

    // Instance variables
    int employeeId;
    String employeeName;

    // Constructor
    Employee(String name) {
        employeeName = name;
        employeeCount++;                 // shared count
        employeeId = employeeCount;      // auto-generated ID
    }

    // Static method
    static int getEmployeeCount() {
        return employeeCount;
    }

    // Instance method
    void displayEmployee() {
        System.out.println("Company Name: " + companyName);
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
    }
}

