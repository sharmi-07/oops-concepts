package Sampleworkout;

public class Vehicalesystem{
    public static void main(String[] args) {
        Car c = new Car();
        c.start();
        c.openTrunk();

        Bike b = new Bike();
        b.start();
        b.kickStart();
    }
}
