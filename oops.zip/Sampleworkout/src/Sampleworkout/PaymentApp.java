package Sampleworkout;

public class PaymentApp {

	 public static void main(String[] args) {

	    
	     Payment p;

	     p = new CreditCardPayment();
	     p.pay(1500);   
	     p = new UPIPayment();
	     p.pay(750);    
	 }
	}
