package Sampleworkout;


interface Smartdevice {

 void turnOn();   
 void turnOff();  
}

class SmartLight implements Smartdevice {

 public void turnOn() {
     System.out.println("Smart Light turned ON");
 }

 public void turnOff() {
     System.out.println("Smart Light turned OFF");
 }
}


class SmartFan implements Smartdevice {

 public void turnOn() {
     System.out.println("Smart Fan turned ON");
 }

 public void turnOff() {
     System.out.println("Smart Fan turned OFF");
 }
}


