package Sampleworkout;


class Student {


 public String name;        
 private int marks;        
 protected String grade;    
 int rollNumber;            

 public void setMarks(int marks) {
     if (marks >= 0 && marks <= 100) {
         this.marks = marks;
         calculateGrade();   
     } else {
         System.out.println("Invalid marks");
     }
 }


 private void calculateGrade() {
     if (marks >= 90)
         grade = "A";
     else if (marks >= 75)
         grade = "B";
     else if (marks >= 40)
         grade = "C";
     else
         grade = "Fail";
 }


 public String getGrade() {
     return grade;
 }


 protected void displayBasicInfo() {
     System.out.println("Name: " + name);
     System.out.println("Roll Number: " + rollNumber);
 }
}


class Teacher extends Student {

 void showStudentInfo() {
     displayBasicInfo();          
     System.out.println("Grade: " + grade);  
 }
}


