/**
 * 
 */
/**
 * 
 */
module sampleabstraction {
}