package sampleabstraction;

public class sample {

    public static void main(String[] args) {

        Shape r = new Rectangle(3, 6);
        r.calculateArea();

        Shape c = new Circle(6);
        c.calculateArea();
    }
}