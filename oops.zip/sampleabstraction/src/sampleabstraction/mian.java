package sampleabstraction;

public class mian {

    public static void main(String[] args) {

      
        BankAccount acc1 = new BankAccount();
        acc1.deposit(500);
        acc1.displayAccount();

        System.out.println();

     
        BankAccount acc2 = new BankAccount(2001, 3000);
        acc2.withdraw(1000);
        acc2.displayAccount();
    }
}
