package sampleabstraction;

// Abstract class
abstract class Shape {

    abstract void calculateArea();

    void displayShape() {
        System.out.println("Displaying shape");
    }
}

// Rectangle class
class Rectangle extends Shape {

    int l, b;

    Rectangle(int l, int b) {
        this.l = l;
        this.b = b;
    }

    void calculateArea() {
        System.out.println("Area of Rectangle: " + (l * b));
    }
}

// Circle class
class Circle extends Shape {

    double r;

    Circle(double r) {
        this.r = r;
    }

    void calculateArea() {
        System.out.println("Area of Circle: " + (3.14 * r * r));
    }
}

// Main class
public class Main {

    public static void main(String[] args) {

        Shape r = new Rectangle(3, 6);
        r.calculateArea();

        Shape c = new Circle(6);
        c.calculateArea();
    }
}
