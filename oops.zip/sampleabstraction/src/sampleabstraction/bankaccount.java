package sampleabstraction;

class BankAccount {

    // Attributes
    int accountNumber;
    double balance;

    BankAccount() {
        accountNumber = 1000;  
        balance = 0.0;          
    }

    
    BankAccount(int accNo, double initialBalance) {
        accountNumber = accNo;
        balance = initialBalance;
    }

 
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

  
    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance");
        }
    }


    void displayAccount() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
}


